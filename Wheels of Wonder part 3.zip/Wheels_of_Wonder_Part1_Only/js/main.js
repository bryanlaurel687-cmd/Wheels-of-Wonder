document.addEventListener('DOMContentLoaded', () => {
  const menuButton = document.querySelector('.menu-button');
  const nav = document.getElementById('main-navigation');

  if (menuButton && nav) {
    menuButton.addEventListener('click', () => {
      nav.classList.toggle('open');
      menuButton.setAttribute(
        'aria-expanded',
        nav.classList.contains('open') ? 'true' : 'false'
      );
    });
  }

  const tabs = document.querySelectorAll('.tab-button');
  const panels = document.querySelectorAll('.tab-panel');

  tabs.forEach((button) => {
    button.addEventListener('click', () => {
      const target = button.dataset.tab;

      tabs.forEach((tab) => tab.classList.toggle('active', tab === button));
      panels.forEach((panel) => {
        panel.classList.toggle('active', panel.id === target);
      });
    });
  });

  const accordionButtons = document.querySelectorAll('.accordion-question');
  accordionButtons.forEach((button) => {
    button.addEventListener('click', () => {
      const item = button.parentElement;
      const answer = item.querySelector('.accordion-answer');

      item.classList.toggle('open');
      const isOpen = item.classList.contains('open');
      button.setAttribute('aria-expanded', String(isOpen));
      answer.hidden = !isOpen;
    });
  });

  const modal = document.getElementById('volunteerModal');
  const modalButtons = document.querySelectorAll('[data-open-modal]');
  const closeModalButton = document.querySelector('[data-close-modal]');

  if (modal) {
    modalButtons.forEach((button) => {
      button.addEventListener('click', () => {
        modal.classList.add('visible');
      });
    });

    closeModalButton?.addEventListener('click', () => {
      modal.classList.remove('visible');
    });

    modal.addEventListener('click', (event) => {
      if (event.target === modal) {
        modal.classList.remove('visible');
      }
    });
  }

  const galleryItems = document.querySelectorAll('.gallery-item');
  const lightbox = document.getElementById('lightbox');
  const lightboxImage = document.getElementById('lightboxImage');
  const lightboxCaption = document.getElementById('lightboxCaption');

  galleryItems.forEach((item) => {
    item.addEventListener('click', () => {
      const image = item.querySelector('img');
      if (!image) return;

      lightboxImage.src = image.src;
      lightboxImage.alt = image.alt;
      lightboxCaption.textContent = image.alt;
      lightbox.classList.add('visible');
    });
  });

  lightbox?.addEventListener('click', (event) => {
    if (event.target === lightbox) {
      lightbox.classList.remove('visible');
    }
  });

  const services = [
    {
      title: 'Storytelling Sessions',
      category: 'community',
      price: 'Free',
      description: 'Interactive storytelling experiences that help children build confidence and a love for reading.'
    },
    {
      title: 'Book Loan Programme',
      category: 'reading',
      price: 'Free',
      description: 'Curated reading materials for children, families, and community groups across Gauteng.'
    },
    {
      title: 'School Outreach Visits',
      category: 'education',
      price: 'On request',
      description: 'Literacy support and reading events delivered to schools and learning hubs in local communities.'
    },
    {
      title: 'Volunteer Training',
      category: 'volunteer',
      price: 'Free',
      description: 'Practical guidance and support for volunteers helping run reading programmes and outreach activities.'
    },
    {
      title: 'Community Reading Events',
      category: 'events',
      price: 'R250+',
      description: 'Celebration-based literacy events designed for community gatherings, festivals, and family days.'
    },
    {
      title: 'Sponsorship Packages',
      category: 'support',
      price: 'Flexible',
      description: 'Partnership opportunities for organisations that want to invest in children’s literacy and growth.'
    }
  ];

  const serviceContainer = document.getElementById('serviceList');
  const serviceSearch = document.getElementById('serviceSearch');
  const serviceSort = document.getElementById('serviceSort');

  function renderServices() {
    if (!serviceContainer) return;

    const query = (serviceSearch?.value || '').trim().toLowerCase();
    const sortValue = serviceSort?.value || 'title';

    const filtered = services.filter((service) => {
      const searchText = `${service.title} ${service.category} ${service.description}`.toLowerCase();
      return searchText.includes(query);
    });

    const sorted = [...filtered].sort((a, b) => {
      if (sortValue === 'price') {
        return a.price.localeCompare(b.price);
      }
      return a.title.localeCompare(b.title);
    });

    if (!sorted.length) {
      serviceContainer.innerHTML = '<p class="empty-state">No services match your search. Try another keyword.</p>';
      return;
    }

    serviceContainer.innerHTML = sorted
      .map(
        (service) => `
          <article class="service-card">
            <span class="service-badge">${service.category}</span>
            <h3>${service.title}</h3>
            <p>${service.description}</p>
            <div class="service-meta">
              <strong>${service.price}</strong>
              <button type="button" class="small-button" data-open-modal>Request details</button>
            </div>
          </article>
        `
      )
      .join('');

    serviceContainer.querySelectorAll('[data-open-modal]').forEach((button) => {
      button.addEventListener('click', () => {
        const modal = document.getElementById('volunteerModal');
        modal?.classList.add('visible');
      });
    });
  }

  serviceSearch?.addEventListener('input', renderServices);
  serviceSort?.addEventListener('change', renderServices);
  renderServices();

  const scheduleSelect = document.getElementById('day-selector');
  const scheduleDisplay = document.getElementById('schedule-display');

  if (scheduleSelect && scheduleDisplay) {
    const scheduleMap = {
      monday: {
        title: 'Monday',
        details: ['Soshanguve Community Centre: 9:00 - 12:00', 'Extension 12 Park: 1:00 - 4:00']
      },
      tuesday: {
        title: 'Tuesday',
        details: ['Mabopane Old Library Building: 9:00 - 12:00', 'Unit D Primary School: 1:00 - 3:30']
      },
      wednesday: {
        title: 'Wednesday',
        details: ['City Hall Parking: 9:00 - 12:00', 'West Park Community Centre: 1:00 - 4:00']
      },
      thursday: {
        title: 'Thursday',
        details: ['Atteridgeville Sports Ground: 9:00 - 12:00', 'Buhle Primary School: 1:00 - 3:30']
      },
      friday: {
        title: 'Friday',
        details: ['Mamelodi Library Lawn: 9:00 - 12:00', 'East Park Community Hall: 1:00 - 4:00']
      },
      saturday: {
        title: 'Saturday',
        details: ['Special event reading session: 10:00 - 13:00', 'Rotating location with family story time']
      }
    };

    scheduleSelect.addEventListener('change', () => {
      const selected = scheduleMap[scheduleSelect.value];
      if (!selected) return;

      scheduleDisplay.innerHTML = `
        <h3>${selected.title}</h3>
        ${selected.details.map((item) => `<p>${item}</p>`).join('')}
      `;
    });
  }

  const contactForm = document.getElementById('contactForm');
  if (contactForm) {
    contactForm.addEventListener('submit', async (event) => {
      event.preventDefault();
      const form = event.currentTarget;
      const submitButton = form.querySelector('button[type="submit"]');
      const message = document.getElementById('formMessage');

      const name = form.name.value.trim();
      const email = form.email.value.trim();
      const phone = form.phone.value.trim();
      const reason = form.reason.value;
      const details = form.message.value.trim();

      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      const phonePattern = /^(\+27|0)[0-9\s-]{8,}$/;

      if (!name || !email || !phone || !reason || !details) {
        message.textContent = 'Please complete all required fields before sending your message.';
        message.className = 'form-message error';
        return;
      }

      if (!emailPattern.test(email)) {
        message.textContent = 'Please enter a valid email address.';
        message.className = 'form-message error';
        return;
      }

      if (!phonePattern.test(phone)) {
        message.textContent = 'Please enter a valid South African phone number.';
        message.className = 'form-message error';
        return;
      }

      if (details.length < 20) {
        message.textContent = 'Your message should be at least 20 characters long.';
        message.className = 'form-message error';
        return;
      }

      submitButton.disabled = true;
      submitButton.textContent = 'Sending...';
      message.textContent = 'Submitting your message...';
      message.className = 'form-message info';

      try {
        await fetch('https://jsonplaceholder.typicode.com/posts', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name, email, phone, reason, details })
        });

        const mailSubject = encodeURIComponent(`Wheels of Wonder enquiry: ${reason}`);
        const mailBody = encodeURIComponent(
          `Name: ${name}\nEmail: ${email}\nPhone: ${phone}\nReason: ${reason}\n\nMessage:\n${details}`
        );

        window.location.href = `mailto:info@wheelswonder.org?subject=${mailSubject}&body=${mailBody}`;

        message.textContent = 'Your message has been prepared and your email app has been opened. Thank you for contacting Wheels of Wonder.';
        message.className = 'form-message success';
        form.reset();
      } catch (error) {
        message.textContent = 'There was a problem sending your message. Please try again or email info@wheelswonder.org directly.';
        message.className = 'form-message error';
      } finally {
        submitButton.disabled = false;
        submitButton.textContent = 'Send Message';
      }
    });
  }

  const enquiryForm = document.getElementById('enquiryForm');
  if (enquiryForm) {
    enquiryForm.addEventListener('submit', (event) => {
      event.preventDefault();
      const form = event.currentTarget;
      const messageBox = document.getElementById('formMessage');
      const fullName = form.name.value.trim();
      const email = form.email.value.trim();
      const phone = form.phone.value.trim();
      const enquiryType = form.enquiryType.value;
      const interest = form.interest.value;
      const date = form.preferredDate.value;
      const message = form.message.value.trim();
      const budget = form.budget.value;

      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      const phonePattern = /^(\+27|0)[0-9\s-]{8,}$/;

      if (!fullName || !email || !phone || !enquiryType || !interest || !date || !message) {
        messageBox.textContent = 'Please complete all required fields so we can respond to your enquiry.';
        messageBox.className = 'form-message error';
        return;
      }

      if (!emailPattern.test(email)) {
        messageBox.textContent = 'Please enter a valid email address.';
        messageBox.className = 'form-message error';
        return;
      }

      if (!phonePattern.test(phone)) {
        messageBox.textContent = 'Please enter a valid South African mobile or landline number.';
        messageBox.className = 'form-message error';
        return;
      }

      if (message.length < 20) {
        messageBox.textContent = 'Please add a little more detail about your enquiry so our team can help you.';
        messageBox.className = 'form-message error';
        return;
      }

      const costMessage = budget ? `We can prepare a tailored estimate in the range of R${budget} and share availability for ${interest}.` : 'We can provide a recommended budget estimate after discussing the programme details.';

      let response = `Thank you, ${fullName}. For the ${enquiryType.toLowerCase()} enquiry about ${interest}, we can confirm availability for ${date}. ${costMessage} A member of the Wheels of Wonder team will contact you within 2 working days.`;

      if (enquiryType === 'Sponsorship') {
        response = `Thank you, ${fullName}. We appreciate your support for ${interest}. We can confirm sponsorship opportunities and partnership availability for ${date}. ${budget ? 'A preliminary contribution range of R' + budget + ' can be discussed with our team.' : 'We can guide you on the best sponsorship level to match your organisation.'}`;
      }

      messageBox.textContent = response;
      messageBox.className = 'form-message success';
      form.reset();
    });
  }
});
