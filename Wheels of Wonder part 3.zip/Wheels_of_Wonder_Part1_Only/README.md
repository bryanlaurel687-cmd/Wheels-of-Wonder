# Wheels of Wonder

Wheels of Wonder is a community-focused mobile library project designed to promote literacy, storytelling, and access to books for children and families in Gauteng. This website showcases the organisation’s mission, service offerings, community impact, enquiry process, and contact information.

## Project overview

The website has been developed as a responsive static site with interactive JavaScript features, SEO-focused metadata, and user-friendly forms. It is structured to provide clear navigation for visitors interested in volunteering, donating, requesting information, or contacting the team.

## Features implemented

- Responsive multi-page website with consistent branding and navigation
- Mobile-friendly layout and navigation menu
- Search and filtering for services on the services page
- Accordion, tabs, modal, and lightbox interactions using JavaScript
- Client-side validation for enquiry and contact forms
- AJAX-style form submission feedback for better user experience
- SEO-friendly page titles, meta descriptions, keywords, and semantic HTML
- robots.txt and sitemap.xml files for search engine indexing
- README changelog covering Part 2 corrections and Part 3 updates

## Part 3 requirements covered

- JavaScript interactivity: accordions, tabs, modal windows, filtering, sorting, image gallery lightbox, and dynamic content rendering
- Search Engine Optimisation: keyword focus, title tags, meta descriptions, heading hierarchy, accessibility, descriptive alt text, internal linking, and mobile responsiveness
- Form implementation: enquiry and contact forms with HTML5 validation and custom JavaScript validation
- AJAX form handling: user feedback states are shown while the form is being processed
- Deployment readiness: project structure is prepared for GitHub Pages or Netlify hosting

## Changelog

### Version 3.0 - Part 3 completion (2026-11-02)

- Rebuilt the website structure to include complete SEO metadata on all main pages.
- Added responsive navigation, improved mobile layouts, and action-focused call-to-action areas.
- Updated the enquiry page to match the Wheels of Wonder community model and included validation, service-based response logic, and user-friendly form messaging.
- Added a fully functional contact form that gathers name, contact details, enquiry type, and message before compiling a pre-filled email draft for the team.
- Implemented JavaScript functionality including accordions, tabs, modal windows, a lightbox image gallery, and service search/filtering.
- Added dynamic rendering for service content, making the services page interactive and easier to browse.
- Created a dedicated JavaScript file to separate behaviour from structure and improve maintainability.
- Added `robots.txt` and `sitemap.xml` files to improve crawlability and SEO indexing.
- Added a README with project details, deployment notes, references, and a changelog of corrections and improvements.
- Corrected previous content inconsistencies, including unclear navigation, outdated vehicle-themed copy, and missing contact form handling.

### Version 2.1 - Part 2 corrections applied

- Corrected broken or inconsistent navigation across pages to ensure all pages link correctly.
- Improved page semantic structure by using clear heading hierarchy and better section grouping.
- Replaced incomplete or mismatched content with consistent Wheels of Wonder messaging.
- Fixed styling inconsistencies by standardising spacing, alignment, and responsive behaviour.
- Improved accessibility with descriptive alt text and better form labelling.

## References

- Google Search Central. (2024). Search Engine Optimization (SEO) starter guide. https://developers.google.com/search/docs/fundamentals/seo-starter-guide
- W3Schools. (2024). HTML forms. https://www.w3schools.com/html/html_forms.asp
- MDN Web Docs. (2024). Client-side form validation. https://developer.mozilla.org/en-US/docs/Learn/Forms/Form_validation
- MDN Web Docs. (2024). JavaScript. https://developer.mozilla.org/en-US/docs/Web/JavaScript
- Netlify. (2024). Deploy static sites. https://www.netlify.com/
- GitHub Pages. (2024). Websites for you and your projects. https://pages.github.com/

## Deployment notes

This project is structured for easy deployment as a static site on Netlify or GitHub Pages. Upload the project folder as-is, or connect the repository to a static hosting service and publish the root folder.

## Git workflow

- Commit changes regularly with descriptive messages.
- Keep one logical change per commit where possible.
- Push final updates to the repository before submission.
- Submit the repository URL and deployment link to the learning platform as required.
